
#ifndef WISE2_MOTT_BRIDGE
#define WISE2_MOTT_BRIDGE

#include "searchstatinterface.h"

SearchStatInterface * new_Mott_SearchStatInterface(void);



#endif
