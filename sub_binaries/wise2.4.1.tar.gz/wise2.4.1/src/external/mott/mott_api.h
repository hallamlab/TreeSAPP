int InitPvaluesMott( int **Matrix, int Gap_init, int Gap_extend, double Pval_threshold );
double SW_PValueMott( double SWScore, char *seqA, char *seqB, int lengthA, int lengthB, int *ok );
