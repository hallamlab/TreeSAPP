

#define VERSION_NUMBER "$Name: wise2-2-0 $"
#define RELEASE_DAY    "unreleased"
#define COMPILE_DATE   __DATE__   

